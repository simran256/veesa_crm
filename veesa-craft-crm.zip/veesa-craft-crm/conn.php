 <?php
    $conn = mysqli_connect("localhost", "web2te_veesa_craft", "Iq1v]9Sla}aJ", "web2te_veesa_craft");
    if (!$conn) {
        die("connection failed" . mysqli_connect_error());
    }
 
    
    $site = "https://web2tech.org/veesa-craft-crm/";
    ?>